package com.krishworks.vplayer;

import android.graphics.Bitmap;

public class video {
    String title;
    String path;
    Bitmap thumbNail;

    public video(String title, String path, Bitmap thumbNail) {
        this.title = title;
        this.path = path;
        this.thumbNail = thumbNail;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Bitmap getThumbNail() {
        return thumbNail;
    }

    public void setThumbNail(Bitmap thumbNail) {
        this.thumbNail = thumbNail;
    }
}
